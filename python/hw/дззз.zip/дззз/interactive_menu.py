from vehicle_crm import VehicleManager


manager = VehicleManager()
manager.show_main_menu()
